import React from 'react';
import ReactDOM from 'react-dom';

class App extends React.Component{
  render(){
    // write Code here:
    return(
    // write Code here:
    )
  }
}

ReactDOM.render(
  <App />,
  document.getElementById('app')
);
